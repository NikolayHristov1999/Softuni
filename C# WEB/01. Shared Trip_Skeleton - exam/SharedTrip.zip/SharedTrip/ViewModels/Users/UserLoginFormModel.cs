﻿namespace SharedTrip.ViewModels.Users
{
    public class UserLoginFormModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
